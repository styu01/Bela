#!/usr/bin/env python3
"""Print a single Codex quota line; reads only the collector snapshot."""

import argparse
import importlib.util
import json
from datetime import datetime, timezone
from pathlib import Path

_spec = importlib.util.spec_from_file_location(
    "codex_usage_collect", Path(__file__).with_name("codex-usage-collect.py"))
collector = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(collector)


def status(used):
    return "STOP" if used >= 90 else "OPATLAN" if used >= 80 else "OK"


def format_snapshot(snapshot, now=None):
    now = now or datetime.now(timezone.utc)
    if not isinstance(snapshot, dict) or snapshot.get("source") != "codex-session-log":
        return "Codex: ISMERETLEN (missing)"
    observed = collector.parse_time(snapshot.get("observed_at"))
    freshness = snapshot.get("freshness")
    if freshness not in ("fresh", "stale", "missing"):
        freshness = "missing"
    if observed is None:
        return "Codex: ISMERETLEN (missing)"
    age = (now - observed).total_seconds()
    if freshness != "fresh" or not 0 <= age <= collector.FRESH_SECONDS:
        return f"Codex: ISMERETLEN ({'missing' if freshness == 'missing' else 'stale'})"
    windows = snapshot.get("windows")
    if not isinstance(windows, dict):
        return "Codex: ISMERETLEN (missing)"
    parts = []
    for name, minutes, label in (("five_hour", 300, "5h"), ("seven_day", 10080, "7nap")):
        window = windows.get(name)
        if not collector.valid_window(window) or window["window_minutes"] != minutes:
            return "Codex: ISMERETLEN (missing)"
        reset = datetime.fromtimestamp(window["resets_at"], timezone.utc).isoformat()
        used = window["used_percent"]
        parts.append(f"{label}: {used:g}% {status(used)}, visszaall: {reset}")
    return "Codex | " + " | ".join(parts)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=collector.DEFAULT_OUTPUT)
    args = parser.parse_args()
    try:
        with args.input.open(encoding="utf-8") as stream:
            snapshot = json.load(stream)
        line = format_snapshot(snapshot)
    except (OSError, ValueError, TypeError, OverflowError, RecursionError):
        line = "Codex: ISMERETLEN (missing)"
    print(line)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
