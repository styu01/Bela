---
name: usage-monitor
description: 30 percenkenti Claude 5-oras ES heti usage ellenorzes (a szamokat egy 10 percenkent futo hatter-cron -- scripts/usage-collect.py -- frissiti a store/usage-latest.json cache-be, ezt csak kiolvassa) + Bela Home v2/okosugyintezo projekt
---

ELSO LEPES -- ROVIDZAR ELLENORZES (kanban 240e6747, 2026-09-12, Istvan kerese; Codex review 2026-09-12 utan finomitva): futtasd le:
python3 /home/kisss/marveen/scripts/usage-monitor-shortcircuit.py

Ez a script a usage-latest.json ERDEMI mezoit (forras, mindket ablak szazaleka+reset-ideje, EGY FRISSESSEG-OSZTALY a generated_at-bol -- fresh/stale/missing/invalid, 25 perces kuszob, NEM maga a nyers idobelyeg) ES a store/.usage-fleet-pause SZEMANTIKUS tartalmat (paused/metric/percent/source, nem a nyers byte-okat) hasonlitja ossze az elozo futassal. A nyers generated_at idobelyeget SZANDEKOSAN nem hasonlitja, mert azt az 10 percenkenti collector-cron minden futasnal ujra beallitja fuggetlenul attol hogy a szamok valtoztak-e -- egy 30 percenkenti osszehasonlitasnal ez szinte SOHA nem egyezne (hasznaltalan rovidzar-jelzes lenne), DE a frissesseg-OSZTALY valtozasat (pl. fresh->stale, ha a collector leall) IGENIS eszreveszi, hogy a kesobbi stale-allapot-kezeles legalabb EGYSZER lefusson.

FONTOS: ez a rovidzar KIZAROLAG a lent kovetkezo USAGE-SPECIFIKUS logikara vonatkozik. A STUCK-MENU ELLENORZES mar NEM resze ennek a feladatnak -- kulon, mindig futo scheduled task ('stuck-menu-scan') vegzi, fuggetlenul attol hogy a usage-allapot valtozott-e (Codex review 2026-09-12: ez egy kulon, kotelezo, valos incidens utan bevezetett biztonsagi kontroll, ami nem szegyulhet a usage-rovidzar melle).

TUDATOS, DOKUMENTALT TRADEOFF (Codex review 2026-09-12, nem-blokkolo eszrevetel): a lenti prompt vege fele talalhato OKOSKA/PROGI inter-agent uzenetlista- es projektstatusz-ellenorzes szinten NEM usage-specifikus, megis ez a rovidzar SKIP eseten EZT is kihagyja. Ez TUDATOS dontes, nem mellekhatas: ez az ellenorzes lenyegesen alacsonyabb tetu mint a kulon-valasztott stuck-menu scan (nincs mogotte dokumentalt, incidens-vezerelt 'kotelezo' minositest), es a usage-monitor sajat, 30 percenkenti cadence-ehez van kotve celszeruen (ha PROGI/OKOSKA epp mernfoldkovet er el, az akkor derul ki amikor a usage-allapot IS valtozik, VAGY legkesobb a legkozelebbi tenyleges PROCEED-futasnal). Ha ez a kesleltetes kesobb problemasnak bizonyul, kulon, mindig-futo taskba erdemes kiemelni -- ATMENETILEG elfogadhato tradeoff-nak minositettuk.

HA A KIMENET "USAGE_MONITOR_SKIP": ALLJ MEG ITT a usage-specifikus reszre nezve. Ne olvasd ujra a usage-latest.json-t, ne ellenorizd az uzenetlistat, ne kuldj se Telegramot se inter-agent uzenetet EBBEN A SZEKCIOBAN. A script mar frissitette a sajat allapotfajljat, neked nincs tovabbi teendod a usage-reszben.

HA A KIMENET "USAGE_MONITOR_PROCEED": valami valtozott (vagy ez az elso futas, vagy a script sajat maga hibazott es fail-open-t valasztott) -- folytasd a TELJES alabbi usage-logikaval, VALTOZATLANUL.

=============================================================

VALODI USAGE ELLENORZES (2026-09-02-tol frissitve -- teljes hatter: docs/usage-tracking-full-operational-analysis-20260901.md):

HATTER-CRON: scripts/usage-collect.py 10 percenkent frissiti a store/usage-latest.json cache-fajlt, NEM neked kell elolrol lekerdezni minden futasnal.

Olvasd ki: cat /home/kisss/marveen/store/usage-latest.json
- generated_at (ISO idobelyeg), claude.source, claude.windows.five_hour.used_percent, claude.windows.seven_day.used_percent (mindketto 0-100), resets_at (unix epoch MASODPERC, UTC-bol Europe/Budapest-re konvertald).
- MEGBIZHATO forras-ertekek: "authoritative", "authoritative_cached", VAGY "authoritative_statusline" (ez utobbi egy dedikalt tracker-session statusLine-exportjabol jon, ugyanolyan megbizhato mint a masik ketto -- 2026-09-01-i fejlesztes, ne kezeld becslesnek).

=== 1. AG: HA A FORRAS NEM A FENTI HAROM EGYIKE (pl. "estimate"), VAGY a fajl hianyzik, VAGY generated_at 25 percnel regebbi ===

Ez egy "kiesesi epizod" kezdete vagy folytatasa. Istvan 2026-09-03-an EXPLICIT kerte: ez a routinjelenseg NEM erdekli, ne kuldj neki Telegramot csak azert mert a forras elavult/becsult -- intezd magad, csendben.

- NE probalj sajat-tokenes fallback lekerdezest (a korabbi /home/kisss/.claude/.credentials.json ut ezen az izolalt fo-agent sessionon NEM letezik, es nincs mas elerheto token-forras/keyring sem -- ez ismert, javithatatlan korlat ebben a kornyezetben, ne toltsd az idot ujra-probalgatassal).
- Olvasd ki store/.usage-stale-alert-state.json (hianyzik/ures = meg nem jeleztel ebben az epizodban). Frissitsd csendben: {"alerted": true, "since": <most, unix epoch>, "last_known_percent_five_hour": <utolso ISMERT reliable ertek ha van a memoriadban/korabbi futasbol>, "last_known_percent_seven_day": <ua>}. Ez csak hazon beluli allapotkovetes, NE kuldj erte Telegramot.
- NINCS TOBBE Telegram-kivetel erre (Istvan 2026-09-04-en MEGISMETELTEN, kifejezetten leallitotta a korabbi "2+ ora vagy 85%+ eseten egyszer jelezz" kivetelt is -- meg az az EGYETLEN engedelyezett eset is tul sok volt neki). Barmilyen stale/estimate epizodra, barmeddig tart, barmilyen ismert utolso ertekkel: SOHA ne kuldj Telegramot csak ezert. Csak a store/.usage-stale-alert-state.json-t frissitsd csendben (lasd fent), "alerted_istvan" mezot mar nem kell hasznalni/irni.
- Ne allj meg uj munka inditasaban CSAK a stale forras miatt -- ez onmagaban nem jelenti hogy a usage tenylegesen magas, csak hogy a pontos szazalek nem elerheto.

=== 2. AG: HA A FORRAS MEGBIZHATO (a fenti harom valamelyike) ES VAN SZAM ===

Elsokent: ha a store/.usage-stale-alert-state.json fajlban "alerted": true all, ez azt jelenti hogy egy korabbi kiesesi epizod most ert veget -- toroljod/uritsd EZT a fajlt (hogy a KOVETKEZO kiesesi epizod ujra egy friss "egyszeri" allapotot kapjon, beleertve az esetleges "alerted_istvan" mezot is), de erre most NE kuldj kulon Telegram-uzenetet, ez csendes hazon belul-takaritas.

Olvasd ki store/.usage-fleet-pause tartalmat JSON-kent (pl. {"paused": true, "metric": "five_hour", "percent": 91.2, "source": "authoritative_statusline", "since": 1788300000} VAGY hianyzik/ures = nincs pause). Ha a fajl a REGI, sima "paused" szoveges formatumban van (nem JSON), kezeld ugy mintha {"paused": true} lenne, es a KOVETKEZO iraskor mar az uj JSON formatumot hasznald.

Istvan 2026-09-20-i dontese (Claude-hasznalat csokkentese fodralt modellek javara): mielott a lenti dontesi logikat vegrehajtod, kuldd el a nyers szamokat (five_hour%, seven_day%, source, jelenlegi pause-allapot) a fodralt `codex/programozo`-nak inter-agent uzenetben, roviden kerve tole: "kell-e pause-t inditani/feloldani a lenti szabaly szerint, es ha igen melyiket". A javaslatat vedd figyelembe, DE a tenyleges dontes, a JSON allapotfajl irasa, a Telegram- es inter-agent-kuldes VALTOZATLANUL NALAD marad -- ez csak egy masodik-velemeny lepes, nem helyettesiti a sajat ellenorzesedet. Ha codex nem valaszol gyorsan (pl. 60 mp-en belul), NE varj tovabb ra, folytasd a sajat dontesed alapjan es jegyezd fel hogy codex kimaradt.

Istvan kerte 2026-08-07-en hogy a HETI (seven_day) hatarra IS ugyanugy alljunk meg 90%-nal, ne csak az otoranira -- az alabbi szabaly MINDKETTORE egyformán vonatkozik:

- Ha (five_hour >= 90 VAGY seven_day >= 90):
  - Ha JELENLEG NINCS pause allapotban, VAGY a tarolt allapot metrikaja/szazaleka/forrasa ERDEMBEN mas mint most (uj info, nem csak ismetles): kuldj inter-agent uzenetet PROGINAK, OKOSKANAK ES IRISNEK (POST /api/messages, from bela, kulon-kulon), tartalom: "MEGOSZTOTT USAGE >=90% ([melyik metrika] X%, resets_at Europe/Budapest idoben). NE indits UJ munkat amig nem jelzem hogy feloldva -- amit eppen csinalsz, fejezd be, de utana varj." (codex-nek NEM kell kuldeni, kulon keretet hasznal.) Kuldj Telegramot Istvannak is (melyik metrika, pontos %, reset-ido). Utana ird a JSON allapotot: {"paused": true, "metric": "<five_hour vagy seven_day>", "percent": <szam>, "source": "<claude.source erteke>", "since": <most>}.
  - Ha UGYANAZ a helyzet mint amit mar tarolsz (nincs erdemi valtozas a metrikaban/szazalekban/forrasban): NE kuldj ujra semmit, csendben maradj.
- Ha 80-90 kozott (egyik sincs 90 felett): NE inditsal uj NAGY feladatot Priginek/OKOSKA-nak, hagyd befejezni amit csinal, de meg nem kell megallni. (Megjegyzes: ez ma viselkedesi ajanlas, nincs technikai kikenyszeritve -- kulon kodszintu munka fut ra, ne ess kesztetesbe hogy magad probald "kikenyszeriteni" mashogy.)
- Ha MINDKETTO (five_hour < 80 ES seven_day < 80) ES az allapot-fajl szerint jelenleg paused: kuldj FELOLDAS inter-agent uzenetet ugyanennek a harom agensnek ("Usage limit feloldva (five_hour X%, seven_day Y%), folytathatjatok uj munkat."), ES kuldj egy rovid Telegram-megerositest Istvannak IS (ez korabban hianyzott -- 2026-09-02-tol kotelezo resz), majd toroljod/uritsd a store/.usage-fleet-pause fajlt.
- Minden mas esetben (pl. az egyik metrika meg 80-90 kozott van, vagy meg nem mindketto esett 80 ala), ha mar paused az allapot: ne kuldj se uj pause-t se feloldast, csak varj (hiszterezis, hogy ne pattogjon oda-vissza a hataron).

Ellenőrizd az OKOSKA ÉS PROGI fejlesztési folyamatot is: van-e új inter-agent üzenet amit feldolgozni kell (curl -s -H "Authorization: Bearer $(cat /home/kisss/marveen/store/.dashboard-token)" http://localhost:3420/api/messages?agent=bela). Ha PROGI mérföldkő-eredménnyel jelentkezett a Béla Home v2 vagy az okosugyintezo.hu projektben, nézd át röviden a leírt munkát, majd jelezd Istvannak Telegramon tömören hol tart a projekt.
